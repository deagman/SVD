.. _library_api:

########################################
rocSOLVER API
########################################

.. toctree::
   :maxdepth: 5

   api_types
   api_auxiliaryfunc
   api_lapackfunc
   api_lapacklike
   api_loggingfunc
   api_deprecated

