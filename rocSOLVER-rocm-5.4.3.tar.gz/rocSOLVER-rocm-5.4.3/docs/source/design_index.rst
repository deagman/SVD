
########################################
rocSOLVER Library Design Guide
########################################

.. toctree::
   :maxdepth: 5

   design_intro
   design_batch
   design_tuning
   design_contribute
