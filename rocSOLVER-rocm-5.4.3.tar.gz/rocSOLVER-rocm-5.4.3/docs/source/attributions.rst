.. _attributions:

########################################
License & Attributions
########################################

.. toctree::
   :maxdepth: 5

.. mdinclude:: ../../LICENSE.md
